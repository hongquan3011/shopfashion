package duan.edu.entity;
 
 
import lombok.Data;


import javax.persistence.*;
import javax.validation.constraints.NotEmpty;



import java.io.Serializable;
import java.util.Date; 
@SuppressWarnings("serial")
@Entity 
@Data
@Table(name= "Feelbacks")
public class Feelback implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;
    @Column(columnDefinition = "nvarchar(225)",nullable = false)
    @NotEmpty(message ="Đánh giá không được để trống")
    String contents;
    @Column(columnDefinition = "nvarchar(225)",nullable = false)
    @NotEmpty(message ="Mô tả không được để trống")
    String description; 
    @Temporal(TemporalType.DATE)
    @Column(name = "feelbackday",nullable = false)
    Date feelbackday = new Date();
    @ManyToOne
   	@JoinColumn(name = "product")
   	Product product;
     @ManyToOne
   	@JoinColumn(name = "account")
   	Account account;
    
  }
