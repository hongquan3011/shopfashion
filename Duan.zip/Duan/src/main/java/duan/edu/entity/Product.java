package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "Products")
public class Product implements Serializable {
	@Id
	@Column(columnDefinition = "varchar(50)")
	@NotEmpty(message = "Mã phẩm không được để trống")
	String id;
	@Column(columnDefinition = "nvarchar(250)",nullable = false)
	@NotEmpty(message = "Tên sản phẩm không được để trống")
	String name;
	@Column(nullable = false)
	@Min(0)
	Integer amount;
	@Column(columnDefinition = "varchar(155)",nullable = false)
	@NotEmpty(message = "Hình ảnh không được để trống")
	String image;
	@Column(columnDefinition = "nvarchar(250)")
	@NotEmpty(message = "Mô tả không được để trống")
	String description;
	@Column(columnDefinition = "varchar(50)")
	String discount;
	@Temporal(TemporalType.DATE)
	@Column(name = "createDay",nullable = false)
	Date createDay = new Date();
	@Column(nullable = false)
	Boolean status;
	@Column(nullable = false)
	Boolean MaleOrFemale;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<TableColor> tablecolor;
	@OneToMany(mappedBy = "product")
	List<TableSize> tablesize;
	@ManyToOne
	@JoinColumn(name = "brand")
	Brand brand;
	@ManyToOne
	@JoinColumn(name = "category")
	Category category;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<OrderDetail> orderdetail ;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<Feelback> feelback  ;
	@JsonIgnore
	@OneToMany(mappedBy = "product")
	List<ImportInvoices> importinvoices   ;
	
}