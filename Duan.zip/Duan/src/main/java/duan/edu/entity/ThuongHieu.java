package duan.edu.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
@SuppressWarnings("serial")
@Entity 
@Data
@Table(name ="ThuongHieu")
public class ThuongHieu implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(50)")
	@NotEmpty(message = "Mã thương hiệu không được để trống")
	String maThuonghieu;
	@Column(columnDefinition = "nvarchar(150)",nullable = false)
	@NotEmpty(message = "Tên thương hiệu không được để trống")
	String tenThuonghieu;
	@JsonIgnore
	@OneToMany(mappedBy = "thuongHieu")
	List<SanPham> sanPham;
}
