package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "SanPham")
public class SanPham implements Serializable {
	@Id
	@Column(columnDefinition = "varchar(50)")
	@NotEmpty(message = "Mã phẩm không được để trống")
	String ID;
	@Column(columnDefinition = "nvarchar(250)",nullable = false)
	@NotEmpty(message = "Tên sản phẩm không được để trống")
	String tenSanpham;
	@Column(nullable = false)
	@Min(0)
	Integer soLuong;
	@Column(columnDefinition = "varchar(155)",nullable = false)
	@NotEmpty(message = "Hình ảnh không được để trống")
	String hinhAnh;
	@Column(columnDefinition = "nvarchar(250)")
	@NotEmpty(message = "Mô tả không được để trống")
	String moTa;
	@Column(columnDefinition = "varchar(50)")
	String giamGia;
	@Temporal(TemporalType.DATE)
	@Column(name = "NgayThem",nullable = false)
	Date ngayThem = new Date();
	@Column(nullable = false)
	Boolean trangThai;
	@Column(nullable = false)
	Boolean loaiSanPham;
	@JsonIgnore
	@OneToMany(mappedBy = "sanPham")
	List<BangMau> bangMau;
	@OneToMany(mappedBy = "sanPham")
	List<BangKichThuoc> bangKichThuoc;
	@ManyToOne
	@JoinColumn(name = "ThuongHieu")
	ThuongHieu thuongHieu;
	@ManyToOne
	@JoinColumn(name = "LoaiHang")
	LoaiHang loaiHang;
	@JsonIgnore
	@OneToMany(mappedBy = "sanPham")
	List<ChiTietDH> chiTietDonHang ;
	@JsonIgnore
	@OneToMany(mappedBy = "sanPham")
	List<DanhGia> danhGia  ;
	@JsonIgnore
	@OneToMany(mappedBy = "sanPham")
	List<HoaDonNH> hoaDonNhapHang   ;
	
}