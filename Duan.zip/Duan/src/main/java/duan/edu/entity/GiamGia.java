package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType; 
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty; 

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Entity 
@Data
@Table(name = "GiamGia")
public class GiamGia  implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	Integer ID;  
	@Column(columnDefinition = "varchar(50)",nullable = false)
	@NotEmpty
	String maVoucher;
	@Column(columnDefinition = "nvarchar(50)",nullable = false)
	@NotEmpty(message = "Tên voucher không được rỗng")
	String tenVoucher;
	@Column(nullable = false)
	@NotEmpty(message = "Giá trị voucher không được rỗng")
	@Min(1) 
	Float giaTri;
	@Column(nullable = false)
	Boolean trangThai;
	@Temporal(TemporalType.DATE) 
	@Column(name = "ngayhethan",nullable = false)
	Date ngayHetHan;
	@Temporal(TemporalType.DATE)
	@Column(name = "ngaysudung",nullable = false)
	Date ngaySuDung;
	@JsonIgnore
	@OneToMany(mappedBy = "giamGia")
	List<DonHang> donHang;
	
	@ManyToOne
	@JoinColumn(name = "NguoiDung")
	NguoiDung nguoiDung;
}
