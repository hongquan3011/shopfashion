package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;


@SuppressWarnings("serial")
@Entity 
@Data
@Table(name ="NguoiDung")
public class NguoiDung implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(50)")
	@NotEmpty(message = "Tài khoản không được để trống")
	String taiKhoan;
	@Column(columnDefinition = "varchar(50)",nullable = false) 
	@NotEmpty(message = "Mật khẩu  không được để trống")
	String matKhau;
	@Column(columnDefinition = "nvarchar(100)",nullable = false)
	@NotEmpty(message = "Họ tên không được để trống")
	String hoTen;
	@Column(columnDefinition = "varchar(12)",nullable = false)
	@NotEmpty(message = "Số điện thoại  không được để trống")
	String sdt;
	@Column(columnDefinition = "varchar(50)",nullable = false)
	@Email(message = "Không đúng định dạng email")
	@NotEmpty(message = "Email  không được để trống")
	String email;
	@Temporal(TemporalType.DATE)
	@JoinColumn(name = "ngaytao")
	Date ngayTao= new Date();
	@Column(columnDefinition = "varchar(50)")
	String hinhAnh;
	@Column(columnDefinition = "nvarchar(225)",nullable = false)
	@NotEmpty(message = "Địa chỉ không được để trống")
	String diaChi;
	@Column(nullable = false)
	Boolean gioiTinh;
	@Column(nullable = false)
	Boolean trangThai;
	@Column(nullable = false) 
   boolean vaitro;
	 @Column  
		@Min(0)
		Integer diemtv;
		@Column 
		@Min(0)
		Integer diemtd;
	 
	@JsonIgnore
	@OneToMany(mappedBy = "nguoiDung")
	List<DonHang> donHang;
	@JsonIgnore
	@OneToMany(mappedBy = "nguoiDung")
	List<GiamGia> giamGia;
 
	@JsonIgnore
	@OneToMany(mappedBy = "nguoiDung")
	List<DanhGia> danhGia ;
	@JsonIgnore
	@OneToMany(mappedBy = "nguoiDung")
	List<HoaDonNH> hoaDonNhapHang ;
	 
}
