package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@SuppressWarnings("serial")
@Entity 
@Data

@Table(name = "ImportInvoices")
public class ImportInvoices implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id; 
	@Min(1) 
	@Column(nullable = false)
	Integer amount;
	@Column(nullable = false)
	@NotEmpty(message = "Giá trị nhập hàng không được rỗng")
	@Min(1) 
	Float purchaseprice;
	@Column(nullable = false)
	@NotEmpty(message = "Giá trị bán hàng không được rỗng")
	@Min(1) 
	Float sellprice;
	@Temporal(TemporalType.DATE) 
	@JoinColumn(name = "createday")
	Date createday = new Date();
	 @ManyToOne
	   	@JoinColumn(name = "account")
	   	Account account;
	 @ManyToOne
	   	@JoinColumn(name = "product")
	 Product product;
	    
}
