package duan.edu.entity;
 
 
import lombok.Data;


import javax.persistence.*;
import javax.validation.constraints.NotEmpty;



import java.io.Serializable;
import java.util.Date; 
@SuppressWarnings("serial")
@Entity 
@Data
@Table(name= "DanhGia")
public class DanhGia implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer ID;
    @Column(columnDefinition = "nvarchar(225)",nullable = false)
    @NotEmpty(message ="Đánh giá không được để trống")
    String danhGia;
    @Column(columnDefinition = "nvarchar(225)",nullable = false)
    @NotEmpty(message ="Mô tả không được để trống")
    String moTa; 
    @Temporal(TemporalType.DATE)
    @Column(name = "ngaydanhgia",nullable = false)
    Date ngaydanhgia = new Date();
    @ManyToOne
   	@JoinColumn(name = "SanPham")
   	SanPham sanPham;
     @ManyToOne
   	@JoinColumn(name = "NguoiDung")
   	NguoiDung nguoiDung;
    
  }
