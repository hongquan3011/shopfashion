package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;


@SuppressWarnings("serial")
@Entity 
@Data
@Table(name ="Accounts")
public class Account implements Serializable{
	@Id
	@Column(columnDefinition = "varchar(50)")
	@NotEmpty(message = "Tài khoản không được để trống")
	String username;
	@Column(columnDefinition = "varchar(50)",nullable = false) 
	@NotEmpty(message = "Mật khẩu  không được để trống")
	String password;
	@Column(columnDefinition = "nvarchar(100)",nullable = false)
	@NotEmpty(message = "Họ tên không được để trống")
	String fullname;
	@Column(columnDefinition = "varchar(12)",nullable = false)
	@NotEmpty(message = "Số điện thoại  không được để trống")
	String numberphone;
	@Column(columnDefinition = "varchar(50)",nullable = false)
	@Email(message = "Không đúng định dạng email")
	@NotEmpty(message = "Email  không được để trống")
	String email;
	@Temporal(TemporalType.DATE)
	@JoinColumn(name = "createday")
	Date createday= new Date();
	@Column(columnDefinition = "varchar(50)")
	String image;
	@Column(columnDefinition = "nvarchar(225)",nullable = false)
	@NotEmpty(message = "Địa chỉ không được để trống")
	String address;
	@Column(nullable = false)
	Boolean gender;
	@Column(nullable = false)
	Boolean status;
	@Column(nullable = false) 
    Boolean role;
	 @Column  
		@Min(0)
		Integer Memberpoint;
		@Column 
		@Min(0)
		Integer Usedpoint;
	 
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Order> order;
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Voucher> voucher;
 
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<Feelback> feelback ;
	@JsonIgnore
	@OneToMany(mappedBy = "account")
	List<ImportInvoices> importinvoices ;
	 
}
