package duan.edu.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import duan.edu.service.OrderService;

@Controller
public class MyOrderController {
	@Autowired
	OrderService orderService;
@RequestMapping("myorder")
public String myorder(Model model,HttpServletRequest request) {
	String username = request.getRemoteUser();
	model.addAttribute("orders", orderService.findbyTaiKhoan(username));
	return "order/myorder";
}
@RequestMapping("myorder/detail{id}")
public String detail(@PathVariable("id") Integer id,Model model) {
	model.addAttribute("order", orderService.findById(id));
	return "order/orderdetail";
}
}
