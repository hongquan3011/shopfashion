package duan.edu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProductController {
	@RequestMapping("productdetail")
public String productdetail() {
	return "product/productdetail.html";
}
	@RequestMapping("product")
public String product() {
	return "product/product.html";
}
}
