package duan.edu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import duan.edu.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService sanPhamService;
	@RequestMapping("productdetail")
public String productdetail() {
	return "product/productdetail.html";
}
	@RequestMapping("product")
public String list(Model model) {
		model.addAttribute("product", sanPhamService.findAll());
	return "product/product.html";
}
}
