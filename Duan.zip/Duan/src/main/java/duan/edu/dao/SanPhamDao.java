package duan.edu.dao; 

import org.springframework.data.jpa.repository.JpaRepository;
 
 
 
public interface SanPhamDao extends JpaRepository<SanPhamDao, String>{ 
	}

