package duan.edu.dao; 

import org.springframework.data.jpa.repository.JpaRepository;

import duan.edu.entity.NguoiDung; 
 
 
public interface NguoiDungDao extends JpaRepository<NguoiDung, String>{ 
	}

