package duan.edu.dao; 

import org.springframework.data.jpa.repository.JpaRepository;

import duan.edu.entity.Voucher; 
 
public interface GiamGiaDao extends JpaRepository<Voucher, Integer>{ 
	}

