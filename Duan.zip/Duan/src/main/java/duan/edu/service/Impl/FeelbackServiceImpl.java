package duan.edu.service.Impl;
 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.FeelbackDAO; 
import duan.edu.service.FeelbackService; 
@Service
public class FeelbackServiceImpl implements FeelbackService {
@Autowired
FeelbackDAO dao;


}
