package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.MauSacDao;
import duan.edu.service.MauSacService;
@Service
public class MauSacServiceImpl implements MauSacService {
@Autowired
MauSacDao dao;
}
