package duan.edu.service.Impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.SanPhamDao;
import duan.edu.entity.Product;
import duan.edu.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService {
@Autowired
SanPhamDao dao;

@Override
public List<Product> findAll() {
	// TODO Auto-generated method stub
	return dao.findAll();
}
}
