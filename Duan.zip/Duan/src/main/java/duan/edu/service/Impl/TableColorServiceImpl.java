package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.BangMauDao; 
import duan.edu.service.TableColorService; 
@Service
public class TableColorServiceImpl implements TableColorService {
@Autowired
BangMauDao dao;
}
