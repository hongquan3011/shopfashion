package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.BangKichThuocDao;
import duan.edu.service.BangKichThuocService; 
@Service
public class  BangKichThuocServiceImpl implements BangKichThuocService{
	@Autowired
	BangKichThuocDao dao;
	
}
