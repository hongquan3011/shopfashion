 
package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.DonHangDao; 
import duan.edu.service.DonHangService; 
@Service
public class DonHangServiceImpl implements DonHangService {
@Autowired
DonHangDao dao;
}
