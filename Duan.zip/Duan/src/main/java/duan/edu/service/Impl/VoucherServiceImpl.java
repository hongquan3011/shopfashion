 
package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.GiamGiaDao; 
import duan.edu.service.VoucherService; 
@Service
public class VoucherServiceImpl implements VoucherService {
@Autowired
GiamGiaDao dao;
}
