 
package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.HoaDonNHDao; 
import duan.edu.service.HoaDonNHService; 
@Service
public class HoaDonNHServiceImpl implements HoaDonNHService {
@Autowired
HoaDonNHDao dao;
}
