package duan.edu.service;

public interface VoucherService {

}
