package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.NguoiDungDao;
import duan.edu.service.AccountService;
@Service
public class AccountServiceImpl implements AccountService {
@Autowired
NguoiDungDao dao;
}
