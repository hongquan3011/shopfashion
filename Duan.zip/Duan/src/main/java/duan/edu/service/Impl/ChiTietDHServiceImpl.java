package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ChiTietDHDao; 
import duan.edu.service.ChiTietDHService; 
@Service
public class ChiTietDHServiceImpl implements ChiTietDHService {
@Autowired
ChiTietDHDao dao;
}
