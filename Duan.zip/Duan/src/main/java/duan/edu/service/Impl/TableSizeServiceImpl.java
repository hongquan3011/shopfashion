package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.TableSizeDAO;
import duan.edu.service.TableSizeService; 
@Service
public class  TableSizeServiceImpl implements TableSizeService{
	@Autowired
	TableSizeDAO dao;
	
}
