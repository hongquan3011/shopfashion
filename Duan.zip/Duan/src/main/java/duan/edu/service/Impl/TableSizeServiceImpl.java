package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.BangKichThuocDao;
import duan.edu.service.TableSizeService; 
@Service
public class  TableSizeServiceImpl implements TableSizeService{
	@Autowired
	BangKichThuocDao dao;
	
}
