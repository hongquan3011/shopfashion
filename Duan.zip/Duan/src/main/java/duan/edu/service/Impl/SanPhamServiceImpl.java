package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.SanPhamDao;
import duan.edu.service.SanPhamService;
@Service
public class SanPhamServiceImpl implements SanPhamService {
@Autowired
SanPhamDao dao;
}
