package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.KichThuocDao;
import duan.edu.service.SizeService;
@Service
public class SizeServiceImpl implements SizeService {
@Autowired
KichThuocDao dao;
}
