package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ColorDAO;
import duan.edu.service.ColorService;
@Service
public class ColorServiceImpl implements ColorService {
@Autowired
ColorDAO dao;
}
