package duan.edu.service;

public interface BangMauService {

}
