package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.BrandDAO;
import duan.edu.service.BrandService;

@Service
public class BrandServiceImpl implements BrandService{
@Autowired
BrandDAO dao;
}
