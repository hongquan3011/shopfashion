package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.KichThuocDao;
import duan.edu.service.KichThuocService;
@Service
public class KichThuocServiceImpl implements KichThuocService {
@Autowired
KichThuocDao dao;
}
