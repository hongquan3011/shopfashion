package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ThuongHieuDao;
import duan.edu.service.ThuongHieuService;

@Service
public class ThuongHieuServiceImpl implements ThuongHieuService{
@Autowired
ThuongHieuDao dao;
}
