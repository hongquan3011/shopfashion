package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.SizeDAO;
import duan.edu.service.SizeService;
@Service
public class SizeServiceImpl implements SizeService {
@Autowired
SizeDAO dao;
}
