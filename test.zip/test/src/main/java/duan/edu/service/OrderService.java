package duan.edu.service;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import duan.edu.entity.Order;

public interface OrderService {
	List<Order> findbyTaiKhoan(String username);

	Order findById(Integer id);
	
	Order create(JsonNode orderData);
}
