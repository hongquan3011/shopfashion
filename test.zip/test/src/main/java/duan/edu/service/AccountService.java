package duan.edu.service;

public interface AccountService {

}
