package duan.edu.service;

import java.util.List;

import duan.edu.entity.Product;

/**
 * @author FPTShop
 *
 */
public interface ProductService {
	List<Product> findAll();

}
