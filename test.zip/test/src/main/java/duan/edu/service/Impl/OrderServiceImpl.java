 
package duan.edu.service.Impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import duan.edu.dao.OrderDetailDAO;
import duan.edu.dao.OrderDAO;
import duan.edu.entity.Order;
import duan.edu.entity.OrderDetail;
import duan.edu.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
@Autowired
OrderDAO dao;
@Autowired
OrderDetailDAO ctDao;

public List<Order> findbyTaiKhoan(String username) {
	return dao.findbyUsername(username);
}

public Order findById(Integer id) {
	return dao.findById(id).get();
}

@Override
public Order create(JsonNode orderData) {
	ObjectMapper mapper = new ObjectMapper();
	
	Order order = mapper.convertValue(orderData, Order.class);
	dao.save(order);
	
	TypeReference<List<OrderDetail>> type = new TypeReference<List<OrderDetail>>() {
	};
	List<OrderDetail> details = mapper.convertValue(orderData.get("orderDetails"), type)
			.stream().peek(d -> d.setOrder(order)).collect(Collectors.toList());
	ctDao.saveAll(details);
	
	return order;
}


}
