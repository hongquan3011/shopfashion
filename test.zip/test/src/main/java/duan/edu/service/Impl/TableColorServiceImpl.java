package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.TableColorDAO; 
import duan.edu.service.TableColorService; 
@Service
public class TableColorServiceImpl implements TableColorService {
@Autowired
TableColorDAO dao;
}
