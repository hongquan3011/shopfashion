 
package duan.edu.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import duan.edu.dao.ImportInvoicesDAO; 
import duan.edu.service.ImportInvoicesService; 
@Service
public class ImportInvoicesServiceImpl implements ImportInvoicesService {
@Autowired
ImportInvoicesDAO dao;
}
