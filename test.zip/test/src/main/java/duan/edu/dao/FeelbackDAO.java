package duan.edu.dao; 

import org.springframework.data.jpa.repository.JpaRepository;

import duan.edu.entity.Feelback; 
 
public interface FeelbackDAO extends JpaRepository<Feelback, Integer>{ 
	}

