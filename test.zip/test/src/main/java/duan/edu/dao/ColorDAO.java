package duan.edu.dao; 

import org.springframework.data.jpa.repository.JpaRepository;

import duan.edu.entity.Color; 
 
 
public interface ColorDAO extends JpaRepository<Color, Integer>{ 
	}

