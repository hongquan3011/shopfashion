package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty; 
import javax.validation.constraints.Null;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data; 

@SuppressWarnings("serial")
@Entity 
@Data
@Table(name = "Orders")
public class Order  implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	Integer id; 
	@Column(columnDefinition = "nvarchar(50)",nullable = false)
	@NotEmpty(message = "Tên người nhận không được rỗng")
	String fullname;
	@Column(columnDefinition = "varchar(12)",nullable = false)
	@NotEmpty(message = "Số điện thoại người nhận không được rỗng")
	String numberphone;
	@Column(columnDefinition = "nvarchar(225)",nullable = false)
	@NotEmpty(message = "Địa chỉ người nhận không được rỗng")
	String address;
	@Temporal(TemporalType.DATE) 
	@Column(name = "orderday",nullable = false)
	Date orderday = new Date();
	 
	@Column(columnDefinition = "varchar(12)",nullable = false)
	@NotBlank
	String status;
    @ManyToOne
    @JoinColumn(name = "username")
    Account account;
	@JsonIgnore
	@OneToMany(mappedBy = "order")
	List<OrderDetail> orderdetail;
	@ManyToOne
    @JoinColumn(name = "voucher")
    Voucher voucher;
	
}
