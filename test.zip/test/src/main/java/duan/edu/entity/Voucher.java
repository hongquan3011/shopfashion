package duan.edu.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType; 
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty; 

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@SuppressWarnings("serial")
@Entity 
@Data
@Table(name = "Vouchers")
public class Voucher  implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	Integer id;  
	@Column(columnDefinition = "varchar(50)",nullable = false)
	@NotEmpty
	String vouchercode;
	@Column(columnDefinition = "nvarchar(50)",nullable = false)
	@NotEmpty(message = "Tên voucher không được rỗng")
	String vouchername;
	@Column(nullable = false)
	@NotEmpty(message = "Giá trị voucher không được rỗng")
	@Min(1) 
	Float value;
	@Column(nullable = false)
	Boolean status;
	@Temporal(TemporalType.DATE) 
	@Column(name = "expiredday",nullable = false)
	Date expiredday;
	@Temporal(TemporalType.DATE)
	@Column(name = "usedday",nullable = false)
	Date usedday;
	@JsonIgnore
	@OneToMany(mappedBy = "voucher")
	List<Order> order;
	
	@ManyToOne
	@JoinColumn(name = "username")
	Account account;
}
